<?php

require_once "../class/mysql_crud.php";

	//if(isset($_POST['submit']))
	//{
		$name = htmlspecialchars($_POST['name']);
		$clg_name = htmlspecialchars($_POST['clg_name']);
		$email = htmlspecialchars($_POST['email']);
		$number = htmlspecialchars($_POST['mob_no']);
		$gender = htmlspecialchars($_POST['gender']);
		$address = htmlspecialchars($_POST['address']);
		$dob = htmlspecialchars($_POST['dob']);


		$db = new Database();
		$db->connect();
		
		$name = $db->escapeString($name); // Escape any input before insert
		$clg_name = $db->escapeString($clg_name);
		$email = $db->escapeString($email);
		$number = $db->escapeString($number);
		$gender = $db->escapeString($gender);
		$address = $db->escapeString($address);
		$dob = $db->escapeString($dob);



		$db->insert('register',array('name'=>$name, 'clg_name'=>$clg_name, 'email'=>$email,'mob_no'=>'$number','gender'=>$gender, 'dob'=>$dob));  // Table name, column names and respective values
		$res = $db->getResult();  
		print_r($res);
		

	//}


?>