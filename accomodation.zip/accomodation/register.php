<html>
<head>
	<title>
		Register
	</title>
</head>
<body>
	<form action="controller/register.php" method="POST">
		Name:<input type="text" name="name" /><br><br>
		Clg name:<input type="text" name="clg_name" /><br><br>
		Email:<input type="email" name="email" /><br><br>
		Mobile no:<input type="number" name="mob_no" /><br><br>
		Gender:<input type="text" name="gender" /><br><br>
		Address:<input type="text" name="address" /><br><br>
		DOB:<input type="text" name="dob" /><br><br>
		<input type="submit" name="submit" />
	</form>
</body>
</html>